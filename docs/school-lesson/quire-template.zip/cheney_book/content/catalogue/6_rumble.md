---
label:
title: Group 6 Rumble object
short_title:
layout: entry
order: 119
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.