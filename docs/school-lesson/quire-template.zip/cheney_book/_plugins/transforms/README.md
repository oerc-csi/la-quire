## Eleventy Transforms

[Eleventy Transforms](https://www.11ty.dev/docs/config/#transforms) are functions that modify template output. A transform function must return the original *or* transformed content.
