## Eleventy _shortcode components_

Add functional, stateless, components from [`_includes/components/`](`_includes/components/`) as Eleventy universal shortcodes.
