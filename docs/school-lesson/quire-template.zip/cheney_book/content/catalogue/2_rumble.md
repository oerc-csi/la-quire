---
label:
title: Group 2 Rumble object
short_title:
layout: entry
order: 115
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.