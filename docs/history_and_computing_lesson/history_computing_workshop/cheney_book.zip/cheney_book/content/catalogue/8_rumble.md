---
label:
title: Group 8 Rumble object
short_title:
layout: entry
order: 121
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.