## Eleventy _shortcode components_

The functional, stateless, [_cross templating language_] components defined in this directory are added as Eleventy shortcodes by the [`components` plugin module](`master/plugins/components/README.md`).

Eleventy JavaScript shortcodes allow using JavaScript and Node.js, including NPM packages, to work with Quire data, including async data.
