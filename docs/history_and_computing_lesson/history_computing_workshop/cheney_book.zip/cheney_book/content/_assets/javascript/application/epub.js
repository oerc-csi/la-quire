/**
 * @fileOverview
 * @name epub.js
 * @description This file serves as the entry point for Webpack, the JS library
 * responsible for building all CSS assets for the EPUBS and MOBI
 */

// Stylesheets
import '../css/epub.scss'
