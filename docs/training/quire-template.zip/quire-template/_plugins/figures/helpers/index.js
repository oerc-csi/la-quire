module.exports = {
  isCanvas: require('./is-canvas'),
  isImageService: require('./is-image-service'),
  isSequence: require('./is-sequence')
}
