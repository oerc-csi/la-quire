## Quire Global Data Plugin

The [`globalData` plugin](_plugins/globalData) uses the [configured data extensions](_plugins/dataExtensions) to parse Quire data files and add the data to Eleventy global data, making the Quire data available to the shortcode [components](_includes/components/).
