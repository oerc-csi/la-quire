---
label:
title: Group 6 Ashmolean object
short_title:
layout: entry
order: 107
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.