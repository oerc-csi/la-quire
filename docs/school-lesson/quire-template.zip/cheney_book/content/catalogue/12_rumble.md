---
label:
title: Group 12 Rumble object
short_title:
layout: entry
order: 125
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.