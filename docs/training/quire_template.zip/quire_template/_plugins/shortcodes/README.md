
## Shortcodes

Any universal filters or shortcodes will also be available as JavaScript Template Functions.

> If you aren’t using an arrow function, JavaScript Functions (and Nunjucks, Liquid, and Handlebars Shortcodes) will have access to Eleventy page data values without needing to pass them in as arguments.
