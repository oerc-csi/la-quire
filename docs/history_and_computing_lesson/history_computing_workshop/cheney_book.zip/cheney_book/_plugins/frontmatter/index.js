module.exports = function(eleventyConfig, options) {
  eleventyConfig.setFrontMatterParsingOptions({

  })
}
