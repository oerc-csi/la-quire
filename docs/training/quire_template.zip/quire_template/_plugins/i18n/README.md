## Eleventy Internationalization Plugin

This plugin helps to manage links between content but does *not* localize content. See the [Eleventy Internationalization (I18n) plugin documentation](https://www.11ty.dev/docs/plugins/i18n/) and the [Eleventy documentation on Internationalization (I18n)](https://www.11ty.dev/docs/i18n/).
