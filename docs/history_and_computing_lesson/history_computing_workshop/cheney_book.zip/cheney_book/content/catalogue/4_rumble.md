---
label:
title: Group 4 Rumble object
short_title:
layout: entry
order: 117
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.