## Quire Frontmatter Plugin

Custom frontmatter handling using [grey-matter](https://github.com/jonschlinkert/gray-matter)

@todo transform legacy Quire front-matter
