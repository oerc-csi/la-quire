---
label:
title: Group 7 Rumble object
short_title:
layout: entry
order: 120
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.