---
label:
title: Group 10 Rumble object
short_title:
layout: entry
order: 123
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.