---
label:
title: Group 2 Ashmolean object
short_title:
layout: entry
order: 103
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.