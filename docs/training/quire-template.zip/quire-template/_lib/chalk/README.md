## A façade module for the `chalk` library

A logging concern for Quire/11ty implemented using [loglevel](https://github.com/pimterry/loglevel) and [chalk](https://github.com/chalk/).

Nota bene: `chalk` v5 is an ESM only library, Eleventy uses v4. For more information see the [chalk v4 documentation](https://github.com/chalk/chalk/tree/v4.1.2).
