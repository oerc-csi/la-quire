## Data Extensions Plugin

The [`dataExtensions` plugin] configures the [Eleventy Custom Data File Formats](https://www.11ty.dev/docs/data-custom/).
