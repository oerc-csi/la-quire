---
label:
title: Group 3 Ashmolean object
short_title:
layout: entry
order: 104
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.