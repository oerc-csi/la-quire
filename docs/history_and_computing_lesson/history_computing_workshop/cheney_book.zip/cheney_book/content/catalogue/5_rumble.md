---
label:
title: Group 5 Rumble object
short_title:
layout: entry
order: 118
presentation: side-by-side
object:
  - id: blank
---

Write about your object here.