## Eleventy linter configuration plugin

Eleventy runs added linters on input templates *before* applying layouts.
